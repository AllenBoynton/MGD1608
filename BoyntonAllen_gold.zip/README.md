# MGD-1608
Mobile Game Design

Allen Boynton

https://github.com/AllenBoynton/MGD-1608

3 Sprites - I have more than that but the Bi-Plane, Bullet and Star, 4 enemy planes, 2 ally planes, etc.

2 Sound Effects - Sound of planes, gunfire sound, thunderstorm sound plus many more

1 Type of input control (tap) - Release of tap fires bullets

1 Point entity is moving plane by clicking on screen or dragging

1 entity collision is bullet to enemy

linear interpolation is cloud moving around and all planes on a random flight pattern

2 Game events - Tapping the screen will move the plane on the y axis, Tapping the screen will fire the bullet and produce a machine gun firing sound. Dragging on the screen will move the plane and give a rapid fire.

1 Bi-Plane animation or stars that spin and get bigger then smaller.

1 pause button - temperamental - within the HUD function. Health meter, to be under plane, is in the works.

1 score label and 1 health label

3 or more emitters when bullets are shot, cloud pours rain…

Game works fine on either iPhone 6 or 6 Plus also my iPad when set up for it in main VC

Game Over functions in place. Will have separate scene with score and either Game Over or Victory.



